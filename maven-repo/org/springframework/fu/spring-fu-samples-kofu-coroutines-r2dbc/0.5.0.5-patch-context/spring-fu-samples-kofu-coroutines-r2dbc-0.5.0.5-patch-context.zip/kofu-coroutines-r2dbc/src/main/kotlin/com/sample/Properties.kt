package com.sample

class SampleProperties(val message: String)
