package com.sample

data class User(
	val login: String,
	val firstname: String,
	val lastname: String
)