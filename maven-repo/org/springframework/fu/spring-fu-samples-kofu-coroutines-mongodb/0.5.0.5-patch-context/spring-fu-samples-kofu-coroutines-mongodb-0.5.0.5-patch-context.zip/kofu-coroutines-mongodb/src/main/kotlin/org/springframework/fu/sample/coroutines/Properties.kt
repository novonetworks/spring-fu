package org.springframework.fu.sample.coroutines

class SampleProperties(val message: String)